#include "apr_optional.h"

APR_DECLARE_OPTIONAL_FN(int,TestOptionalFn,(const char *));
