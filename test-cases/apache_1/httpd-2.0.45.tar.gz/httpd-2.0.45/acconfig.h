/* Define this if struct tm has a field tm_gmtoff */
#undef HAVE_GMTOFF
